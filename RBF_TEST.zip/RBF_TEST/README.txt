DRY-RUN FIX: PC sender + required Vitis main.c change.

Replace the PC send_rbf.py file with the included version.

Modify Vitis main.c (receiver) BEFORE testing dry-run:

REPLACE the original block that starts:
   if(selected>4U || bytes_total==0U || ... || !ENABLE_WRITE){tx('E');continue;}
and runs through the SECOND region configuration/address check (immediately
before tx('C');) WITH this complete block:

   if (selected > 4U || bytes_total == 0U ||
       bytes_total > RBF_REGION_BYTES ||
       reg(RBF_SIG) != 0x53464C31U ||
       (selected == 0U && !ALLOW_MASTER_ERASE)) {
     tx('E');
     continue;
   }
   if (rbf_config_region(selected, bytes_total) != 0) {
     tx('E');
     continue;
   }
   actual_base = selected * 0x002D0000U;
   if (reg(RBF_START) != actual_base ||
       reg(RBF_END_LAST) != (actual_base + bytes_total - 1U)) {
     tx('E');
     continue;
   }
   if (!ENABLE_WRITE) {
     tx('T');
     continue;
   }
   tx('C'); /* starts destructive sequence when enabled */

Ensure the original tx('C'); does not remain twice!
Keep ENABLE_WRITE=0; ALLOW_MASTER_ERASE=0.
Rebuild and run application on ZedBoard and close any terminal occupying COM4.

In Windows PowerShell:
python "C:\Users\kumar\Downloads\RBF_TEST\send_rbf.py" COM4 1 "C:\Users\kumar\TEST_S0.RBF" --dry-run

Expected: DRY RUN PASS; NO FLASH modification.
