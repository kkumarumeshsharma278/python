
"""
ZedBoard SPI Flash RBF Programmer
Compatible with Vitis 2019.2 firmware.

PC -> UART -> Zynq ARM -> AXI SPI Flash IP -> Micron Flash

FPGA selectors:
    0 = MASTER
    1 = SLAVE 0
    2 = SLAVE 1
    3 = SLAVE 2
    4 = SLAVE 3

Protocol:
    Board sends 'R' while ready.

    PC sends:
        b'RBF1'
        selector (1 byte)
        file size (4 bytes little-endian)
        CRC32 (4 bytes little-endian)

    Board replies:
        T = Dry-run PASS
        C = Accepted, erase starting
        D = Erase completed
        A = Chunk accepted
        V = Send file again for verification
        P = Byte-for-byte PASS
        E = Error

IMPORTANT:
    Both PC and Vitis must use CHUNK=16.
"""

import argparse
import pathlib
import struct
import time
import zlib

import serial


# ============================================================
# CONFIGURATION
# ============================================================

REGION_SIZE = 0x2C0000
REGION_STRIDE = 0x2D0000

CHUNK = 16

FPGA_NAMES = {
    0: "MASTER",
    1: "SLAVE 0",
    2: "SLAVE 1",
    3: "SLAVE 2",
    4: "SLAVE 3",
}


# ============================================================
# UART RESPONSE HANDLING
# ============================================================

def wait_reply(port, expected, timeout=120):
    """
    Wait for one specific response byte.

    Return only when expected response arrives.
    Reject E and unexpected responses.
    """

    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:

        reply = port.read(1)

        if not reply:
            continue

        if reply == expected:
            return

        if reply == b"E":
            raise RuntimeError(
                "ZedBoard reported ERROR (E)"
            )

        raise RuntimeError(
            f"Expected {expected!r}, received {reply!r}"
        )

    raise RuntimeError(
        f"Timeout waiting for response {expected!r}"
    )


def wait_initial_reply(port, expected, timeout=30):
    """
    Before first command response, ignore extra R bytes
    from the board's periodic READY beacon.
    """

    deadline = time.monotonic() + timeout
    ready_count = 0

    while time.monotonic() < deadline:

        reply = port.read(1)

        if not reply:
            continue

        if reply == b"R":
            ready_count += 1
            continue

        if reply == expected:
            if ready_count:
                print(
                    f"Ignored {ready_count} extra READY bytes."
                )
            return

        if reply == b"E":
            raise RuntimeError(
                "Board rejected FPGA selection or operation."
            )

        raise RuntimeError(
            f"Unexpected initial reply: {reply!r}"
        )

    raise RuntimeError(
        f"Timeout waiting for {expected!r}"
    )


def wait_ready(port, timeout=30):
    """
    Wait until ZedBoard sends READY ('R').
    """

    print("Waiting for ZedBoard READY (R)...", flush=True)

    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:

        reply = port.read(1)

        if reply == b"R":
            print("ZedBoard READY received.", flush=True)
            return

    raise RuntimeError(
        "Board did not send READY (R). "
        "Check COM port and running Vitis application."
    )


# ============================================================
# FILE CRC32
# ============================================================

def calculate_crc(filename):
    crc = 0

    with filename.open("rb") as f:

        while True:
            block = f.read(65536)

            if not block:
                break

            crc = zlib.crc32(block, crc)

    return crc & 0xFFFFFFFF


# ============================================================
# RBF DATA TRANSFER
# ============================================================

def transfer(port, filename, total_size, phase):
    """
    Transfer exactly CHUNK bytes per packet, except
    possibly the last packet.

    Wait for board acknowledgement 'A' after each packet.

    Prints the exact chunk and byte offset if failure occurs.
    """

    completed = 0
    chunk_number = 0

    with filename.open("rb") as f:

        while completed < total_size:

            count = min(CHUNK, total_size - completed)

            block = f.read(count)

            if len(block) != count:
                raise RuntimeError(
                    "RBF file ended unexpectedly."
                )

            chunk_number += 1

            start_offset = completed
            end_offset = completed + count - 1

            # Send the binary bytes.
            written = port.write(block)

            if written != len(block):
                raise RuntimeError(
                    f"{phase}: Serial write incomplete "
                    f"at chunk {chunk_number}"
                )

            port.flush()

            # Wait for the ZedBoard to finish this packet.
            try:
                wait_reply(port, b"A", timeout=120)

            except Exception as exc:

                raise RuntimeError(
                    f"{phase} FAILED!\n"
                    f"Chunk number: {chunk_number}\n"
                    f"Start offset: 0x{start_offset:06X}\n"
                    f"End offset:   0x{end_offset:06X}\n"
                    f"Last acknowledged bytes: {completed}\n"
                    f"Error: {exc}"
                ) from exc

            completed += count

            # Display useful progress.
            if (
                completed % 256 == 0
                or completed == total_size
            ):
                percent = (completed * 100.0) / total_size

                print(
                    f"{phase}: {completed:,}/"
                    f"{total_size:,} bytes "
                    f"({percent:.1f}%)",
                    flush=True
                )


# ============================================================
# COMMAND-LINE INTERFACE
# ============================================================

def main():

    parser = argparse.ArgumentParser(
        description="ZedBoard 5-FPGA RBF Flash Programmer"
    )

    parser.add_argument(
        "port",
        help="Serial COM port, e.g. COM4"
    )

    parser.add_argument(
        "selector",
        type=int,
        choices=range(5),
        help="0=Master, 1=Slave0, 2=Slave1, 3=Slave2, 4=Slave3"
    )

    parser.add_argument(
        "file",
        type=pathlib.Path,
        help="Path to RBF binary file"
    )

    parser.add_argument(
        "--baud",
        type=int,
        default=115200,
        help="UART baud rate (default 115200)"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only check FPGA selector and range. No erase/write."
    )

    parser.add_argument(
        "--allow-master",
        action="store_true",
        help="Allow destructive operations on Master region."
    )

    args = parser.parse_args()

    # --------------------------------------------------------
    # VALIDATE RBF FILE
    # --------------------------------------------------------

    if not args.file.is_file():
        parser.error(
            f"RBF file not found: {args.file}"
        )

    size = args.file.stat().st_size

    if not 0 < size <= REGION_SIZE:
        parser.error(
            "RBF size must be 1 to 0x2C0000 bytes."
        )

    if (
        args.selector == 0
        and not args.dry_run
        and not args.allow_master
    ):
        parser.error(
            "Master erase is protected. "
            "Use --allow-master only if intentional."
        )

    crc = calculate_crc(args.file)

    flash_start = args.selector * REGION_STRIDE
    flash_end = flash_start + size - 1
    partition_end = flash_start + REGION_SIZE - 1

    # --------------------------------------------------------
    # DISPLAY SELECTION
    # --------------------------------------------------------

    print()
    print("========================================")
    print(" ZEDBOARD RBF FLASH PROGRAMMER")
    print("========================================")

    print(f"FPGA       : {FPGA_NAMES[args.selector]}")
    print(f"Selector   : {args.selector:03b}")
    print(f"RBF file   : {args.file}")
    print(f"RBF size   : {size:,} bytes")
    print(f"CRC32      : {crc:08X}")

    print(f"Flash start   : 0x{flash_start:06X}")
    print(f"Firmware end  : 0x{flash_end:06X}")
    print(f"Partition end : 0x{partition_end:06X}")

    print(f"UART port     : {args.port}")
    print(f"Baud rate     : {args.baud}")
    print(f"UART chunk    : {CHUNK} bytes")

    # --------------------------------------------------------
    # WRITE PROTECTION
    # --------------------------------------------------------

    if args.dry_run:

        print()
        print("DRY RUN: Flash erase/write disabled.")

    else:

        print()
        print(
            "WARNING: This will erase 64 KiB sectors "
            "covering the selected RBF."
        )

        confirm = input(
            "Enter ERASE to continue: "
        ).strip()

        if confirm != "ERASE":
            print("Cancelled.")
            return

    # --------------------------------------------------------
    # CONNECT UART
    # --------------------------------------------------------

    with serial.Serial(
        port=args.port,
        baudrate=args.baud,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=0.5,
        write_timeout=30,
        rtscts=False,
        xonxoff=False
    ) as port:

        # Wait for board READY.
        wait_ready(port, timeout=30)

        # Send binary request header.
        request = (
            b"RBF1"
            + bytes([args.selector])
            + struct.pack("<II", size, crc)
        )

        port.write(request)
        port.flush()

        # ----------------------------------------------------
        # SAFE DRY RUN
        # ----------------------------------------------------

        if args.dry_run:

            wait_initial_reply(port, b"T", timeout=30)

            print()
            print("========================================")
            print(" DRY RUN PASS")
            print("========================================")
            print("FPGA selector and addresses verified.")
            print("No Flash erase or write performed.")

            return

        # ----------------------------------------------------
        # ERASE
        # ----------------------------------------------------

        wait_initial_reply(port, b"C", timeout=30)

        print()
        print("Board accepted region; erasing...", flush=True)

        wait_reply(port, b"D", timeout=240)

        print("Erase completed.", flush=True)

        # ----------------------------------------------------
        # PROGRAM
        # ----------------------------------------------------

        print("Programming RBF...", flush=True)

        transfer(
            port,
            args.file,
            size,
            "WRITE"
        )

        # ----------------------------------------------------
        # VERIFY
        # ----------------------------------------------------

        wait_reply(port, b"V", timeout=120)

        print()
        print(
            "Reading Flash and comparing original RBF...",
            flush=True
        )

        transfer(
            port,
            args.file,
            size,
            "COMPARE"
        )

        # ----------------------------------------------------
        # FINAL RESULT
        # ----------------------------------------------------

        wait_reply(port, b"P", timeout=120)

        print()
        print("========================================")
        print(" FLASH RBF WRITE / READBACK PASS")
        print("========================================")

        print(f"FPGA   : {FPGA_NAMES[args.selector]}")
        print(f"Bytes  : {size:,}")
        print(f"CRC32  : {crc:08X}")
        print("Original RBF matches Flash byte-for-byte.")


if __name__ == "__main__":
    main()
