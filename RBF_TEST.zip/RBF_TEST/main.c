/* ZedBoard Zynq-7000 Vitis 2019.2, PC UART -> AXI -> SPI Flash.
 * Requires the EXISTING 6-bit address AXI region IP from previous package.
 * spi_flash_controller.vhd is NOT changed.
 * Binary protocol on PS UART; do not use xil_printf on this same UART.
 * Destructive writes are DISABLED by default. Set ENABLE_WRITE to 1 only
 * after reviewing and verifying the selected region.
 */
#include "xparameters.h"
#include "xil_io.h"
#include "xil_types.h"
#include "xuartps_hw.h"
#include "sleep.h"
#include "flash_rbf_region.h"

#define ENABLE_WRITE 0
#define ALLOW_MASTER_ERASE 0
#define CHUNK 256U
#define LIMIT 2000000U
#if defined(XPAR_XUARTPS_1_BASEADDR)
#define PC_UART XPAR_XUARTPS_1_BASEADDR
#elif defined(XPAR_PS7_UART_1_BASEADDR)
#define PC_UART XPAR_PS7_UART_1_BASEADDR
#elif defined(XPAR_XUARTPS_0_BASEADDR)
#define PC_UART XPAR_XUARTPS_0_BASEADDR
#else
#error "No Zynq PS UART address in xparameters.h"
#endif

static u8 chunk[CHUNK];
static u32 bytes_total;
static unsigned selected;
static u32 crc_file;
static u32 crc_verify;
static void tx(u8 ch) { XUartPs_SendByte(PC_UART, ch); }
static u8 rx(void) { return (u8)XUartPs_RecvByte(PC_UART); }
static u32 reg(u32 a) {return rbf_reg(a);}
static void put(u32 a,u32 v) {rbf_put(a,v);}
static u32 get32(void) {u32 n=0;unsigned i;for(i=0;i<4;i++)n|=((u32)rx())<<(8*i);return n;}
static u32 crc_add(u32 c,u8 v) {unsigned i;c^=v;for(i=0;i<8;i++)c=(c>>1)^((c&1U)?0xEDB88320U:0U);return c;}
static int cmd(u32 command) {
 u32 i,f;
 if(reg(RBF_FLAGS)&RBF_F_BUSY)return -1;
 put(RBF_CTRL,command);
 for(i=0;i<LIMIT;i++) {
   f=reg(RBF_FLAGS);
   if(f&(RBF_F_ILLEGAL_WRITE|RBF_F_ILLEGAL_ERASE|RBF_F_RANGE|RBF_F_SELECT))return -2;
   if(f&RBF_F_DONE)return 0;
   usleep(10);
 }
 return -3;
}
static int status_ok(void){
 if(cmd(2U))return -1;
 if(!(reg(RBF_FLAGS)&RBF_F_VALID))return -1;
 return ((reg(RBF_STATUS)&1U)==0U)?0:-1;
}
static int read_byte(u32 offs,u8 *v){
 put(RBF_OFFSET,offs);
 if(cmd(1U))return -1;
 if(!(reg(RBF_FLAGS)&RBF_F_VALID))return -1;
 *v=(u8)(reg(RBF_DOUT)&0xffU);return 0;
}
static int erase_sector(u32 offs){
 put(RBF_OFFSET,offs);
 if(cmd(5U))return -1;
 return status_ok();
}
static int prog_byte(u32 offs,u8 b){
 if(b==0xffU)return 0; /* after confirmed sector erase */
 put(RBF_OFFSET,offs);put(RBF_DIN,b);
 if(cmd(4U))return -1;
 return status_ok();
}
static void drain_and_ack(void){tx('A');}
int main(void){
 u8 a,b,v;u32 n,i,j,take,expected_crc,actual_base;
 /* PC expects raw single-letter responses. Do not call init_platform():
    FSBL/Vitis boot environment is assumed initialized already. */
 for(;;){
   tx('R');
   if(rx()!='R'||rx()!='B'||rx()!='F'||rx()!='1'){tx('E');continue;}
   selected=(unsigned)rx();
   bytes_total=get32(); expected_crc=get32();
   if(selected>4U || bytes_total==0U || bytes_total>RBF_REGION_BYTES ||
      reg(RBF_SIG)!=0x53464C31U ||
      (selected==0U&&!ALLOW_MASTER_ERASE) || !ENABLE_WRITE){tx('E');continue;}
   if(rbf_config_region(selected,bytes_total)!=0){tx('E');continue;}
   actual_base=selected*0x002D0000U;
   if(reg(RBF_START)!=actual_base||reg(RBF_END_LAST)!=(actual_base+bytes_total-1U)) {tx('E');continue;}
   tx('C'); /* configuration accepted, erase will follow */
   for(n=0;n<bytes_total;n+=RBF_SECTOR_BYTES){
     if(erase_sector(n)!=0){tx('E');break;}
   }
   if(n<bytes_total)continue;
   tx('D'); /* erased; PC can start sending chunks */
   crc_file=0xffffffffU;
   for(n=0;n<bytes_total;){
     take=(bytes_total-n>CHUNK)?CHUNK:(bytes_total-n);
     for(i=0;i<take;i++)chunk[i]=rx();
     for(i=0;i<take;i++){
       crc_file=crc_add(crc_file,chunk[i]);
       if(prog_byte(n+i,chunk[i])!=0)break;
     }
     if(i!=take){tx('E');break;}
     n+=take; drain_and_ack();
   }
   if(n<bytes_total)continue;
   if((crc_file^0xffffffffU)!=expected_crc){tx('E');continue;}
   tx('V'); /* PC retransmits the original file for byte comparison */
   crc_verify=0xffffffffU;
   for(n=0;n<bytes_total;){
     take=(bytes_total-n>CHUNK)?CHUNK:(bytes_total-n);
     for(i=0;i<take;i++)chunk[i]=rx();
     for(j=0;j<take;j++){
       if(read_byte(n+j,&v)!=0||v!=chunk[j])break;
       crc_verify=crc_add(crc_verify,v);
     }
     if(j!=take){tx('E');break;}
     n+=take;drain_and_ack();
   }
   if(n<bytes_total)continue;
   tx(((crc_verify^0xffffffffU)==expected_crc)?'P':'E');
 }
}
