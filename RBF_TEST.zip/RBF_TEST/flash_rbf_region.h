#ifndef FLASH_RBF_REGION_H
#define FLASH_RBF_REGION_H
#include "xparameters.h"
#include "xil_io.h"
#include "xil_types.h"
#ifndef XPAR_SPI_FLASH_IP_0_S00_AXI_BASEADDR
#error "Regenerate Vitis BSP from the new XSA"
#endif
#define RBF_AXI XPAR_SPI_FLASH_IP_0_S00_AXI_BASEADDR
#define RBF_REGION_BYTES 0x002C0000U
#define RBF_SECTOR_BYTES 0x00010000U
#define RBF_CTRL 0x00U
#define RBF_OFFSET 0x04U
#define RBF_DIN 0x08U
#define RBF_FLAGS 0x0CU
#define RBF_DOUT 0x10U
#define RBF_STATUS 0x14U
#define RBF_ID 0x18U
#define RBF_SIG 0x1CU
#define RBF_SELECT 0x20U
#define RBF_SIZE 0x24U
#define RBF_START 0x28U
#define RBF_END_LAST 0x2CU /* inclusive firmware end */
#define RBF_PART_END 0x30U /* inclusive partition end */
#define RBF_PHYSICAL_ADDR 0x34U
#define RBF_F_BUSY 1U
#define RBF_F_DONE 2U
#define RBF_F_VALID 4U
#define RBF_F_ILLEGAL_WRITE 8U
#define RBF_F_ILLEGAL_ERASE 16U
#define RBF_F_RANGE 32U
#define RBF_F_SELECT 64U
static inline u32 rbf_reg(u32 off) {return Xil_In32(RBF_AXI+off);}
static inline void rbf_put(u32 off,u32 value){Xil_Out32(RBF_AXI+off,value);}
static inline int rbf_config_region(u32 selection, u32 file_bytes){
  u32 base, end;
  if(selection > 4U || file_bytes == 0U || file_bytes > RBF_REGION_BYTES) return -1;
  if(rbf_reg(RBF_FLAGS)&RBF_F_BUSY) return -2;
  rbf_put(RBF_SELECT,selection); /* clears old firmware size and offset */
  rbf_put(RBF_SIZE,file_bytes); /* sets actual length of selected .RBF */
  base=selection*0x002D0000U;
  end=base+file_bytes-1U;
  if((rbf_reg(RBF_SELECT)&7U)!=selection ||
      rbf_reg(RBF_SIZE)!=file_bytes ||
      rbf_reg(RBF_START)!=base ||
      rbf_reg(RBF_END_LAST)!=end) return -3;
  return 0;
}
#endif
