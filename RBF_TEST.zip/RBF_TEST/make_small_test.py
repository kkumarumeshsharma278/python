from pathlib import Path
import sys
selector=int(sys.argv[1]) if len(sys.argv)>1 else 1
if selector not in range(5): raise ValueError('selector must be 0..4')
name=['MASTER','SLAVE0','SLAVE1','SLAVE2','SLAVE3'][selector]+'.RBF'
Path('TEST_'+name).write_bytes(bytes(((i*37+selector*53+(i>>8)) & 255) for i in range(4096)))
print('Created TEST_'+name,'4096 bytes')
