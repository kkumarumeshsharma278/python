
/*
 * ZedBoard Zynq-7000 - Vitis 2019.2
 *
 * PC UART -> AXI4-Lite -> Micron SPI Flash
 *
 * FPGA selection:
 *   0 = Master
 *   1 = Slave 0
 *   2 = Slave 1
 *   3 = Slave 2
 *   4 = Slave 3
 *
 * Each FPGA region: 0x2C0000 bytes
 * Region spacing:  0x2D0000 bytes
 *
 * IMPORTANT:
 * spi_flash_controller.vhd is NOT modified.
 *
 * UART protocol uses binary characters.
 * Do not call xil_printf() on this same UART.
 */

#include "xparameters.h"
#include "xil_io.h"
#include "xil_types.h"
#include "xuartps_hw.h"
#include "sleep.h"
#include "flash_rbf_region.h"

/* =========================================================
 * SAFETY SETTINGS
 * ========================================================= */

#define ENABLE_WRITE        0
#define ALLOW_MASTER_ERASE  0

/* =========================================================
 * CONSTANTS
 * ========================================================= */

#define CHUNK 16U
#define LIMIT              2000000U

#define REGION_STRIDE      0x002D0000U
#define SIGNATURE_VALUE    0x53464C31U

/* =========================================================
 * PS UART ADDRESS
 * ========================================================= */

#if defined(XPAR_XUARTPS_1_BASEADDR)
#define PC_UART XPAR_XUARTPS_1_BASEADDR
#elif defined(XPAR_PS7_UART_1_BASEADDR)
#define PC_UART XPAR_PS7_UART_1_BASEADDR
#elif defined(XPAR_XUARTPS_0_BASEADDR)
#define PC_UART XPAR_XUARTPS_0_BASEADDR
#else
#error "Zynq PS UART base address not found"
#endif

/* =========================================================
 * GLOBAL VARIABLES
 * ========================================================= */

static u8 chunk[CHUNK];

static u32 bytes_total;
static unsigned selected;

static u32 crc_file;
static u32 crc_verify;

/* =========================================================
 * UART FUNCTIONS
 * ========================================================= */

static void uart_tx(u8 value)
{
    XUartPs_SendByte(PC_UART, value);
}

static u8 uart_rx(void)
{
    return (u8)XUartPs_RecvByte(PC_UART);
}

/*
 * Sends 'R' repeatedly while waiting for a PC request.
 * Prevents the PC missing a one-time ready message.
 */
static void uart_wait_for_pc(void)
{
    for (;;) {

        uart_tx('R');

        /* 100 milliseconds */
        usleep(100000);

        if (XUartPs_IsReceiveData(PC_UART) != 0U) {
            break;
        }
    }
}

static u32 uart_get32(void)
{
    u32 value = 0U;
    unsigned i;

    for (i = 0U; i < 4U; i++) {

        value |= ((u32)uart_rx()) << (8U * i);
    }

    return value;
}

/* =========================================================
 * AXI REGISTER FUNCTIONS
 * ========================================================= */

static u32 reg_read(u32 offset)
{
    return rbf_reg(offset);
}

static void reg_write(u32 offset, u32 value)
{
    rbf_put(offset, value);
}

/* =========================================================
 * CRC32
 * ========================================================= */

static u32 crc32_add(u32 crc, u8 value)
{
    unsigned i;

    crc ^= value;

    for (i = 0U; i < 8U; i++) {

        if ((crc & 1U) != 0U) {
            crc = (crc >> 1U) ^ 0xEDB88320U;
        } else {
            crc >>= 1U;
        }
    }

    return crc;
}

/* =========================================================
 * SPI FLASH COMMAND
 * ========================================================= */

static int flash_command(u32 command)
{
    u32 flags;
    u32 i;

    flags = reg_read(RBF_FLAGS);

    if ((flags & RBF_F_BUSY) != 0U) {
        return -1;
    }

    reg_write(RBF_CTRL, command);

    for (i = 0U; i < LIMIT; i++) {

        flags = reg_read(RBF_FLAGS);

        if ((flags &
             (RBF_F_ILLEGAL_WRITE |
              RBF_F_ILLEGAL_ERASE |
              RBF_F_RANGE |
              RBF_F_SELECT)) != 0U) {

            return -2;
        }

        if ((flags & RBF_F_DONE) != 0U) {
            return 0;
        }

        usleep(10);
    }

    return -3;
}

/* =========================================================
 * FLASH STATUS
 * ========================================================= */

static int flash_status_ok(void)
{
    if (flash_command(2U) != 0) {
        return -1;
    }

    if ((reg_read(RBF_FLAGS) & RBF_F_VALID) == 0U) {
        return -1;
    }

    /* Check WIP == 0 */
    if ((reg_read(RBF_STATUS) & 1U) != 0U) {
        return -1;
    }

    return 0;
}

/* =========================================================
 * READ ONE FLASH BYTE
 * ========================================================= */

static int flash_read_byte(u32 offset, u8 *value)
{
    reg_write(RBF_OFFSET, offset);

    if (flash_command(1U) != 0) {
        return -1;
    }

    if ((reg_read(RBF_FLAGS) & RBF_F_VALID) == 0U) {
        return -1;
    }

    *value = (u8)(reg_read(RBF_DOUT) & 0xFFU);

    return 0;
}

/* =========================================================
 * ERASE 64 KiB FLASH SECTOR
 * ========================================================= */

static int flash_erase_sector(u32 offset)
{
    reg_write(RBF_OFFSET, offset);

    if (flash_command(5U) != 0) {
        return -1;
    }

    return flash_status_ok();
}

/* =========================================================
 * PROGRAM ONE FLASH BYTE
 * ========================================================= */

static int flash_program_byte(u32 offset, u8 value)
{
    /*
     * After successful sector erase, memory is 0xFF.
     * Do not program bytes that are already 0xFF.
     */

    if (value == 0xFFU) {
        return 0;
    }

    reg_write(RBF_OFFSET, offset);
    reg_write(RBF_DIN, value);

    if (flash_command(4U) != 0) {
        return -1;
    }

    return flash_status_ok();
}

/* =========================================================
 * FPGA REGION CONFIGURATION
 * ========================================================= */

static int configure_selected_region(
    unsigned fpga,
    u32 file_size)
{
    u32 expected_start;
    u32 expected_end;

    if (fpga > 4U) {
        return -1;
    }

    if (file_size == 0U ||
        file_size > RBF_REGION_BYTES) {
        return -2;
    }

    if (reg_read(RBF_SIG) != SIGNATURE_VALUE) {
        return -3;
    }

    if (rbf_config_region(fpga, file_size) != 0) {
        return -4;
    }

    expected_start = ((u32)fpga) * REGION_STRIDE;

    expected_end = expected_start + file_size - 1U;

    if (reg_read(RBF_START) != expected_start) {
        return -5;
    }

    if (reg_read(RBF_END_LAST) != expected_end) {
        return -6;
    }

    return 0;
}

/* =========================================================
 * MAIN
 * ========================================================= */

int main(void)
{
    u32 n;
    u32 i;
    u32 j;
    u32 take;
    u32 expected_crc;

    u8 value;
    u8 verify_only;
    u8 magic_last;

    /*
     * UART protocol
     *
     * Board -> PC:
     *   'R' = Ready
     *
     * PC -> Board:
     *   "RBF1"
     *   FPGA selector: 1 byte
     *   RBF size:      4 bytes, little-endian
     *   RBF CRC32:     4 bytes, little-endian
     *
     * Board -> PC:
     *   'T' = dry-run passed
     *   'C' = accepted; erase starts
     *   'D' = erase completed
     *   'A' = data chunk accepted
     *   'V' = retransmit file for verification
     *   'P' = byte-for-byte PASS
     *   'E' = error
     */

    for (;;) {

        /* -------------------------------------
         * Wait for PC connection
         * ------------------------------------- */

        uart_wait_for_pc();

        /* -------------------------------------
         * Receive RBF request header
         * ------------------------------------- */

        if (uart_rx() != 'R' ||
            uart_rx() != 'B' ||
            uart_rx() != 'F') {

            uart_tx('E');
            continue;
        }

        /* RBF1 = existing program protocol; RBFV = verify-only */
        magic_last = uart_rx();
        if (magic_last != '1' && magic_last != 'V') {
            uart_tx('E');
            continue;
        }
        verify_only = (magic_last == 'V') ? 1U : 0U;

        selected = (unsigned)uart_rx();

        bytes_total = uart_get32();

        expected_crc = uart_get32();

        /* -------------------------------------
         * Validate request
         * ------------------------------------- */

        if (selected > 4U ||
            bytes_total == 0U ||
            bytes_total > RBF_REGION_BYTES) {

            uart_tx('E');
            continue;
        }

        /* Protect Master region */

        if (!verify_only && selected == 0U &&
            !ALLOW_MASTER_ERASE) {

            uart_tx('E');
            continue;
        }

        /* -------------------------------------
         * Configure FPGA region
         * ------------------------------------- */

        if (configure_selected_region(
                selected,
                bytes_total) != 0) {

            uart_tx('E');
            continue;
        }

        /* -------------------------------------
         * VERIFY-ONLY REQUEST (RBFV)
         * Read and compare ONLY. No erase/write.
         * Works even with ENABLE_WRITE=0 and
         * ALLOW_MASTER_ERASE=0.
         * ------------------------------------- */

        if (verify_only) {
            crc_verify = 0xFFFFFFFFU;
            uart_tx('V');  /* Ready to receive expected bytes */

            for (n = 0U; n < bytes_total;) {
                take = bytes_total - n;
                if (take > CHUNK) {
                    take = CHUNK;
                }

                for (i = 0U; i < take; i++) {
                    chunk[i] = uart_rx();
                }

                for (j = 0U; j < take; j++) {
                    if (flash_read_byte(n + j, &value) != 0) {
                        break;
                    }
                    if (value != chunk[j]) {
                        break;
                    }
                    crc_verify = crc32_add(crc_verify, value);
                }

                if (j != take) {
                    uart_tx('E');
                    break;
                }
                n += take;
                uart_tx('A');
            }

            if (n == bytes_total) {
                crc_verify ^= 0xFFFFFFFFU;
                uart_tx((crc_verify == expected_crc) ? 'P' : 'E');
            }
            continue;
        }

        /* -------------------------------------
         * SAFE DRY RUN
         * ------------------------------------- */

        if (!ENABLE_WRITE) {

            /*
             * Region selected correctly.
             * RBF size checked.
             * START and END registers verified.
             *
             * No Flash erase.
             * No Flash programming.
             */

            uart_tx('T');

            continue;
        }

        /* -------------------------------------
         * REGION ACCEPTED
         * ------------------------------------- */

        uart_tx('C');

        /* -------------------------------------
         * ERASE REQUIRED 64 KiB SECTORS
         * ------------------------------------- */

        for (n = 0U;
             n < bytes_total;
             n += RBF_SECTOR_BYTES) {

            if (flash_erase_sector(n) != 0) {

                uart_tx('E');
                break;
            }
        }

        if (n < bytes_total) {
            continue;
        }

        /* Erase completed */

        uart_tx('D');

        /* -------------------------------------
         * RECEIVE AND PROGRAM RBF
         * ------------------------------------- */

        crc_file = 0xFFFFFFFFU;

        for (n = 0U; n < bytes_total;) {

            take = bytes_total - n;

            if (take > CHUNK) {
                take = CHUNK;
            }

            /* Receive next binary data chunk */

            for (i = 0U; i < take; i++) {
                chunk[i] = uart_rx();
            }

            /* Program each received byte */

            for (i = 0U; i < take; i++) {

                crc_file = crc32_add(
                    crc_file,
                    chunk[i]);

                if (flash_program_byte(
                        n + i,
                        chunk[i]) != 0) {

                    break;
                }
            }

            if (i != take) {

                uart_tx('E');
                break;
            }

            n += take;

            /* Chunk accepted */

            uart_tx('A');
        }

        if (n < bytes_total) {
            continue;
        }

        /* Compare received file CRC32 */

        crc_file ^= 0xFFFFFFFFU;

        if (crc_file != expected_crc) {

            uart_tx('E');
            continue;
        }

        /* -------------------------------------
         * REQUEST ORIGINAL RBF AGAIN
         * ------------------------------------- */

        uart_tx('V');

        crc_verify = 0xFFFFFFFFU;

        /* -------------------------------------
         * READ FLASH AND VERIFY EVERY BYTE
         * ------------------------------------- */

        for (n = 0U; n < bytes_total;) {

            take = bytes_total - n;

            if (take > CHUNK) {
                take = CHUNK;
            }

            /* Receive original bytes from PC */

            for (i = 0U; i < take; i++) {
                chunk[i] = uart_rx();
            }

            /* Read and compare Flash data */

            for (j = 0U; j < take; j++) {

                if (flash_read_byte(
                        n + j,
                        &value) != 0) {

                    break;
                }

                if (value != chunk[j]) {

                    break;
                }

                crc_verify = crc32_add(
                    crc_verify,
                    value);
            }

            if (j != take) {

                uart_tx('E');
                break;
            }

            n += take;

            /* Chunk verified */

            uart_tx('A');
        }

        if (n < bytes_total) {
            continue;
        }

        crc_verify ^= 0xFFFFFFFFU;

        /* -------------------------------------
         * FINAL CRC32 RESULT
         * ------------------------------------- */

        if (crc_verify == expected_crc) {

            uart_tx('P');

        } else {

            uart_tx('E');
        }
    }
}
