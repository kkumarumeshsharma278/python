src/platform.o src/platform.o: ../src/platform.c \
 C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xparameters.h \
 C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xparameters_ps.h \
 C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xil_cache.h \
 C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xil_types.h \
 ../src/platform_config.h

C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xparameters.h:

C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xparameters_ps.h:

C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xil_cache.h:

C:/Users/kumar/Downloads/fla/zedboard_hw_test/zedboard_hw_testvivado/vitis/platform/export/platform/sw/platform/standalone_domain/bspinclude/include/xil_types.h:

../src/platform_config.h:
