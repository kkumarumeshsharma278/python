﻿# MT25QL128 SPI Flash Firmware Simulation

## Overview

ModelSim simulation for SPI Flash firmware programming
and read-back verification.

- Flash type: MT25QL128 / N25Q-compatible model
- Controller: VHDL-2008
- Testbench: VHDL-2008
- Firmware size: 112 KiB
- Total bytes: 114688
- Page size: 256 bytes
- Total pages: 448

## Project Files

- flash_module.v
- mt25ql128_adc_style.vhd
- tb_mt25ql128_bulk_data.vhd
- run_bulk_data.do
- test_data/spi_test_112KB.bin
- test_data/spi_test_112KB.hex

## External Micron Model

N25Qxxx.v is NOT included in this repository.

For simulation, obtain the Micron model separately
from an appropriately licensed source.

Place it here:

    code/N25Qxxx.v

If the model requires additional vendor include files,
place those in:

    include/

## ModelSim Run Procedure

Open ModelSim and change to the repository folder.

### Step 1: Small smoke test

In ModelSim Transcript:

    set TARGET_KIB 1
    do run_bulk_data.do
    run -all

Expected: 1 KiB / 4 pages verified.

### Step 2: Full 112 KiB test

Start a fresh simulation:

    set TARGET_KIB 112
    do run_bulk_data.do
    run -all

Expected: 112 KiB / 448 pages verified.

Look for:

    [PASS BULK DATA] 112 KiB

## Firmware Sequence

1. Start fresh simulation.
2. Load test firmware data from HEX.
3. Program each 256-byte page.
4. Read back each byte.
5. Compare actual versus expected data.
6. Report PASS or FAIL.

Note: The bulk test assumes initially erased Flash.
It does not independently verify a separate erase sequence.

## Previous Results

Previously reported ModelSim result:

- 112 KiB programmed and read back
- 448 pages verified
- Zero mismatches

These results should be reproduced after cloning.

## License

Third-party Micron Verilog model is excluded.
Review the licensing of all included files before
publishing them publicly.

## Hardware Safety

Simulation only. No physical Flash programming.
