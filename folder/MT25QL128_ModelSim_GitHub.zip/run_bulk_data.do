# Run in ModelSim Transcript from C:/Users/kumar/Downloads/fla
# Set target: 1 KiB smoke test, then 90..112 KiB.
if {![info exists TARGET_KIB]} {set TARGET_KIB 1}
if {[catch {quit -sim}]} {}
cd [file dirname [file normalize [info script]]]
if {![file exists work]} {vlib work}
vmap work work
vlog +incdir+. +incdir+./include +define+Feature_8 +define+HOLD_pin ./code/N25Qxxx.v ./flash_module.v
vcom -2008 ./mt25ql128_adc_style.vhd
vcom -2008 ./tb_mt25ql128_bulk_data.vhd
vsim -t 1ps -gTARGET_KIB=$TARGET_KIB -wlf bulk_${TARGET_KIB}KB.wlf work.tb_mt25ql128_bulk_data
# run -all to finish, or run 10 ms for initial inspection

