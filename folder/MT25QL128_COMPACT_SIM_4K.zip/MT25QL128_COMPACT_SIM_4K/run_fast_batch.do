onerror {quit -code 1}
catch {quit -sim}
cd [file dirname [file normalize [info script]]]

if {![file exists work]} {vlib work}
vmap work work

vlog +incdir+. +incdir+./include +define+Feature_8 +define+HOLD_pin ./code/N25Qxxx.v ./flash_module.v
vcom -2008 ./mt25ql128_adc_style.vhd
vcom -2008 ./tb_mt25ql128_bulk_data.vhd

vsim -t 1ps -gTARGET_KIB=4 work.tb_mt25ql128_bulk_data
run -all
quit -code 0
