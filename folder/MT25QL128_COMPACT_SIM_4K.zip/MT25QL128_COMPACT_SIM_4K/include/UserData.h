// Micron MT25QL128 - 128Mb, 3V

// Device selection
//`define MT25TU256HBA8Exx_0xxx
`define MT25QL128ABB8E0
//`define MT25QU128ABB8E0

// Memory density
`define DENSITY_128

// Memory initialization
`define FILENAME_mem_die1 "mem_Q128_die1.vmf"
`define FILENAME_mem_die2 "mem_Q128_die2.vmf"
`define FILENAME_mem      "mem_Q128.vmf"

// Temporarily disable SFDP initialization
`define FILENAME_sfdp ""

// Configuration
`define NVCR_DEFAULT_VALUE 'hFFFF

// Pin configuration
`undef RESET_pin
`define HOLD_pin
`define Feature_8

// Timing
`define TIMING_133