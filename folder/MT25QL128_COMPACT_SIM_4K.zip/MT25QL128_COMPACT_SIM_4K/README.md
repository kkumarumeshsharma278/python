﻿# MT25QL128 ModelSim Compact Firmware Simulation

## Test Configuration

- Firmware size: 4 KiB (4096 bytes)
- Page size: 256 bytes
- Total pages: 16
- Verification: program each page and read back every byte
- Flash model: Micron N25Qxxx.v

## Run in ModelSim GUI

    do run_fast_gui.do

## Run in ModelSim batch mode

    do run_fast_batch.do

## Expected result

    [PASS BULK DATA] 4 KiB

## Notes

The testbench uses a fresh, initially erased Flash model.
It does not perform an explicit firmware-region erase.

The controller used here is mt25ql128_adc_style.vhd,
not spi_flash_controller.vhd.

The Micron vendor files are included for private local
simulation only. Do not redistribute without permission.
