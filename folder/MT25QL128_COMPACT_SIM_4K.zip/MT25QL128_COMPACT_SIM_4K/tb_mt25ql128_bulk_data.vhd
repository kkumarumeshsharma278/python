-- Standalone sequential-data testbench for the original Micron Verilog model.
-- VHDL-2008, compiled alongside the already-verified page256 controller.
-- TARGET_KIB = 1 for smoke test, then 90..112 for full dataset.
-- Reads prefix of test_data/spi_test_112KB.hex derived byte-for-byte from .bin.
-- This creates a fresh flash simulation and never modifies any Micron file.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use ieee.std_logic_textio.all;

entity tb_mt25ql128_bulk_data is
    generic (TARGET_KIB : positive := 1);
end entity;

architecture Behavioral of tb_mt25ql128_bulk_data is
    constant CLK_PERIOD : time := 10 ns;
    constant TOTAL_PAGES : natural := TARGET_KIB * 4;
    component flash_module is
        port (S, C : in std_logic;
              HOLD_DQ3, DQ0, DQ1 : inout std_logic;
              Vcc : in std_logic_vector(31 downto 0);
              Vpp_W_DQ2 : inout std_logic;
              RESET2 : in std_logic);
    end component;
    signal clkin : std_logic := '0';
    signal spi_clkp : std_logic := '0';
    signal reset : std_logic := '1';
    signal rd, rd_sr, wr, sector_erase, bulk_erase, rd_id : std_logic := '0';
    signal page_program : std_logic := '0';
    signal addr : std_logic_vector(23 downto 0) := (others => '0');
    signal datain : std_logic_vector(7 downto 0) := (others => '0');
    signal payload : std_logic_vector(2047 downto 0) := (others => '0');
    signal dataout, status_out, rdid_out : std_logic_vector(7 downto 0);
    signal busy, valid, illegal_write, illegal_erase : std_logic;
    signal scsq, sclk, mosi : std_logic;
    signal dq0, dq1, hold_dq3, wp_dq2 : std_logic := 'Z';
    signal vcc : std_logic_vector(31 downto 0) := (others => '0');
    signal div_count : integer range 0 to 4 := 0;
    procedure start_operation(signal clk : in std_logic;
                              signal busy_sig : in std_logic;
                              signal request : out std_logic) is
    begin
        wait until falling_edge(clk);
        request <= '1';
        wait until rising_edge(busy_sig) for 10 us;
        assert busy_sig = '1' report "Request was not accepted" severity failure;
        wait until falling_edge(clk);
        request <= '0';
    end procedure;
    procedure wait_finished(signal clk : in std_logic;
                            signal busy_sig : in std_logic;
                            timeout_limit : in time := 20 ms) is
    begin
        wait until falling_edge(busy_sig) for timeout_limit;
        assert busy_sig = '0' report "Operation timed out (busy stuck high)" severity failure;
        for k in 1 to 4 loop wait until falling_edge(clk); end loop;
    end procedure;
begin
    assert TARGET_KIB <= 112 report "TARGET_KIB must be 1..112" severity failure;
    clkin <= not clkin after CLK_PERIOD/2;
    clk_enable_proc : process(clkin)
    begin
        if rising_edge(clkin) then
            if reset = '1' then
                div_count <= 0;
                spi_clkp <= '0';
            elsif div_count = 4 then
                div_count <= 0;
                spi_clkp <= '1';
            else
                div_count <= div_count + 1;
                spi_clkp <= '0';
            end if;
        end if;
    end process;
    hold_dq3 <= 'H';
    wp_dq2 <= 'H';
    dq0 <= mosi;
    U_CONTROLLER : entity work.mt25ql128_adc_style
        generic map (CS_GAP_CLKS => 10)
        port map (
            reset => reset, clkin => clkin, spi_clkp => spi_clkp,
            read => rd, rden => '1', addr => addr,
            read_status => rd_sr, write => wr, datain => datain,
            page_program => page_program, page_payload => payload,
            sector_erase => sector_erase, bulk_erase => bulk_erase,
            read_rdid => rd_id, dataout => dataout, busy => busy,
            data_valid => valid, status_out => status_out,
            illegal_write => illegal_write, illegal_erase => illegal_erase,
            rdid_out => rdid_out, scsq => scsq, sclk => sclk,
            dq0 => mosi, dq1 => dq1);
    U_FLASH : flash_module
        port map (S => scsq, C => sclk, HOLD_DQ3 => hold_dq3,
                  DQ0 => dq0, DQ1 => dq1, Vcc => vcc,
                  Vpp_W_DQ2 => wp_dq2, RESET2 => '1');

    stimulus : process
        file input_file : text open read_mode is "test_data/spi_test_112KB.hex";
        variable ln : line;
        variable incoming : std_logic_vector(7 downto 0);
        variable page_bytes : std_logic_vector(2047 downto 0);
        variable correct_count : natural := 0;
        variable a : natural;
    begin
        report "[BULK] Start target=" & integer'image(TARGET_KIB) &
               " KiB, pages=" & integer'image(TOTAL_PAGES) severity note;
        reset <= '1';
        vcc <= (others => '0');
        wait for 100 ns;
        vcc <= std_logic_vector(to_unsigned(3300,32));
        wait for 1 us;
        wait until falling_edge(clkin);
        reset <= '0';
        for k in 1 to 10 loop wait until falling_edge(clkin); end loop;
        -- Virgin flash is erased FF. Use new ModelSim simulation each run.
        for pg in 0 to TOTAL_PAGES-1 loop
            for j in 0 to 255 loop
                assert not endfile(input_file)
                    report "[FAIL DATAFILE] Unexpected end of .hex" severity failure;
                readline(input_file,ln);
                hread(ln,incoming);
                page_bytes(2047-8*j downto 2040-8*j) := incoming;
            end loop;
            payload <= page_bytes;
            a := pg * 256;
            addr <= std_logic_vector(to_unsigned(a,24));
            report "[PAGE START] page=" & integer'image(pg) &
                   " addr=0x" & to_hstring(std_logic_vector(to_unsigned(a,24))) severity note;
            start_operation(clkin,busy,page_program);
            wait_finished(clkin,busy,20 ms);
            for j in 0 to 255 loop
                addr <= std_logic_vector(to_unsigned(a+j,24));
                start_operation(clkin,busy,rd);
                wait_finished(clkin,busy,2 ms);
                assert dataout = page_bytes(2047-8*j downto 2040-8*j)
                    report "[FAIL DATA] page=" & integer'image(pg) &
                           " address=0x" & to_hstring(std_logic_vector(to_unsigned(a+j,24))) &
                           " expected=0x" & to_hstring(page_bytes(2047-8*j downto 2040-8*j)) &
                           " got=0x" & to_hstring(dataout)
                    severity failure;
                correct_count := correct_count+1;
            end loop;
            report "[PAGE PASS] page=" & integer'image(pg) &
                   " verified_bytes=" & integer'image(correct_count) severity note;
            if (pg+1) mod 4 = 0 then
                report "[CHECKPOINT] " & integer'image((pg+1)/4) &
                       " KiB verified" severity note;
            end if;
        end loop;
        report "[PASS BULK DATA] " & integer'image(TARGET_KIB) &
               " KiB, " & integer'image(correct_count) &
               " bytes verified, no mismatch" severity note;
        std.env.stop;
        wait;
    end process;
end Behavioral;
