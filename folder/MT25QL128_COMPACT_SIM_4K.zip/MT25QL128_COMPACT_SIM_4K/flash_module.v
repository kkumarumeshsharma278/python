module flash_module (
    input S,
    input C,
    inout HOLD_DQ3,
    inout DQ0,
    inout DQ1,
    input [31:0] Vcc,
    inout Vpp_W_DQ2,
    input RESET2
);

    N25Qxxx DUT (
        .S(S),
        .C_(C),
        .HOLD_DQ3(HOLD_DQ3),
        .DQ0(DQ0),
        .DQ1(DQ1),
        .Vcc(Vcc),
        .Vpp_W_DQ2(Vpp_W_DQ2),
        .RESET2(RESET2)
    );

endmodule